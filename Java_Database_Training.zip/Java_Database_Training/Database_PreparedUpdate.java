// Write a JDBC code to update the employee name of the specific employee id (using PreparedStatement)
import java.sql.*;
import java.util.Scanner;

public class Database_PreparedUpdate {
    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        // Load driver
        Class.forName("com.mysql.cj.jdbc.Driver");

        // Establish connection
        Connection conn = DriverManager.getConnection("Jdbc:mysql://localhost:3306/Trinity", "root", "root");
        System.out.println("Connected Successfully....");

        // SQL with placeholders
        PreparedStatement ps = conn.prepareStatement("UPDATE Employee SET ename=? WHERE eid=?");
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter the eid: ");
        int id=sc.nextInt();
        System.out.println("Enter the name: ");
        String name=sc.next();
        
        // Create PreparedStatement
       

        // Set parameters
        ps.setInt(2, id);   // new name
        ps.setString(1, name);          // employee id

        // Execute update
        int row = ps.executeUpdate();

        if (row > 0) {
            System.out.println("Updated Successfully.......");
        }

        // Close resources
        ps.close();
        conn.close();
    }
}
