import java.sql.*;
import java.util.*;

public class Database_MenuDriven {
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        Connection conn = null;
        PreparedStatement pst = null;
        ResultSet rs = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("Driver loaded successfully...");

            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/Trinity", "root", "root");
            System.out.println("Connected to the database successfully...");

            while (true) {
                System.out.println("\n=== Project - Department Menu ===");
                System.out.println("1. Insert Record in Department table");
                System.out.println("2. Insert Record in Project table");
                System.out.println("3. Display the Details of all projects");
                System.out.println("4. Display the budget of each department");
                System.out.println("5. Update the HOD name");
                System.out.println("6. Delete projects with status 'Incomplete'");
                System.out.println("7. Exit");
                System.out.print("Enter your Choice: ");
                int choice = sc.nextInt();
                sc.nextLine(); // consume newline

                switch (choice) {
                    case 1:
                        System.out.print("Enter the Department Number: ");
                        int dno = sc.nextInt();
                        sc.nextLine();
                        System.out.print("Enter the Department name: ");
                        String dname = sc.next();
                        System.out.print("Enter HOD: ");
                        String hod = sc.next();

                        pst = conn.prepareStatement("INSERT INTO department VALUES (?,?,?)");
                        pst.setInt(1, dno);
                        pst.setString(2, dname);
                        pst.setString(3, hod);

                        int rows = pst.executeUpdate();
                        System.out.println(rows + " record(s) inserted into Department.");
                        pst.close();
                        break;

                    case 2:
                        System.out.print("Enter the Project Name: ");
                        String pname = sc.next();
                        System.out.print("Enter the Project Status: ");
                        String status = sc.next();
                        System.out.print("Enter the Project Budget: ");
                        int budget = sc.nextInt();
                        System.out.print("Enter the Department Number: ");
                        int pdno = sc.nextInt();
                        sc.nextLine(); // consume newline

                        pst = conn.prepareStatement("INSERT INTO project VALUES (?,?,?,?)");
                        pst.setString(1, pname);
                        pst.setString(2, status);
                        pst.setInt(3, budget);
                        pst.setInt(4, pdno);

                        rows = pst.executeUpdate();
                        System.out.println(rows + " record(s) inserted into Project.");
                        pst.close();
                        break;

                    case 3:
                        pst = conn.prepareStatement("SELECT * FROM project");
                        rs = pst.executeQuery();
                        System.out.println("=== Project Details ===");
                        while (rs.next()) {
                            System.out.println(rs.getString(1) + "  " +
                                    rs.getString(2) + "  " +
                                    rs.getInt(3) + "  " +
                                    rs.getInt(4));
                        }
                        rs.close();
                        pst.close();
                        break;

                    case 4:
                        pst = conn.prepareStatement("SELECT dno, SUM(budget) FROM project GROUP BY dno");
                        rs = pst.executeQuery();
                        System.out.println("=== Department Budgets ===");
                        while (rs.next()) {
                            System.out.println("Department " + rs.getInt(1) + " : Total Budget = " + rs.getInt(2));
                        }
                        rs.close();
                        pst.close();
                        break;

                    case 5:
                        System.out.print("Enter the current HOD name to update: ");
                        String hod1 = sc.next();
                        System.out.print("Enter the new HOD name: ");
                        String hod2 = sc.next();

                        pst = conn.prepareStatement("UPDATE department SET hod=? WHERE hod=?");
                        pst.setString(1, hod2);
                        pst.setString(2, hod1);

                        int updatedRows = pst.executeUpdate();
                        System.out.println(updatedRows + " record(s) updated.");
                        pst.close();
                        break;

                    case 6:
                        pst = conn.prepareStatement("DELETE FROM project WHERE status='Incomplete'");
                        int deletedRows = pst.executeUpdate();
                        System.out.println(deletedRows + " record(s) deleted from Project table.");
                        pst.close();
                        break;

                    case 7:
                        System.out.println("Exiting...");
                        conn.close();
                        sc.close();
                        System.exit(0);

                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
