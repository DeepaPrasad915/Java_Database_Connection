use Trinity;
create table Department(
dno int Primary key,
dname varchar(100),
HOD varchar(100));

create table project(
pname varchar(100) not null,
status varchar(100) check(status in ('Complete', 'Incomplete','progressive')),
budget int check( budget>5000),
dno int,
foreign key (dno) references department (dno)); 

select * from Department;
select *from project;

