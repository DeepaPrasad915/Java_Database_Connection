public class main {
    static int i=1;
    public static void main(String[] args) {
       /* for(int i=1;i<10;i++)
        {
            i=i+2;
            System.err.println(i+"");
        }
            */

            /*int x;
            System.err.println('j'+'a'+'v'+'a');//add ascii value of single letter
        */
        /*int x=10;
        if (x){
        System.out.println("welcome"); 
            
        }*/
    
    }
    
}
