import java.sql.*;
public class Database_Delete {
    public static void main(String[] args)throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn= DriverManager.getConnection("Jdbc:mysql://localhost:3306/Trinity","root","root");
        System.out.println("Connected Successfully");
        Statement st= conn.createStatement();
        int row= st.executeUpdate("Delete from Employee where eid=107");
        if(row>0)
        {
            System.out.println("Deleted Successfully.......");
            st.close();
            conn.close();
        }
    }
    
}
