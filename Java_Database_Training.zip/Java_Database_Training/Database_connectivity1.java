import java.sql.*;
public class Database_connectivity1
{
    public static void main(String args[]) throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn= DriverManager.getConnection("Jdbc:mysql://localhost:3306/Trinity","root","root");
        Statement st= conn.createStatement();
        
        String sql = "INSERT INTO Employee (eid, ename, salary, dname) " +
            "VALUES (107, 'Vijay', 14500, 'IT'), " +
            "(102, 'Gautam', 15000, 'HR'), " +
            "(101, 'Raj', 17500, 'Finance')";
            int rows= st.executeUpdate(sql);
        {
            System.out.println(rows + "rows(s) Inserted Successfully");
            st.close();
            conn.close();
        }
    }
}
