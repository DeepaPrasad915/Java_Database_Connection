//Write a JDBC code to display the details of employee get in the 2nd highest salary.
import java.sql.*;
public class Database_Clause2 {
    public static void main(String[] args) throws SQLException, ClassNotFoundException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=DriverManager.getConnection("Jdbc:mysql://localhost:3306/Trinity","root","root");
        System.out.println("Connected Successfully");
        Statement st= con.createStatement();
        String query= "Select *from employee where salary = (select distinct salary from Employee order by salary desc limit 1,1)";
        ResultSet rs= st.executeQuery(query);//using distinct clause to get unique value of 2nd highest
        while(rs.next())
        {
            System.out.println(rs.getString(1)+" "+rs.getString(2)+" "+rs.getInt(3));
            System.out.println("Displaying value....");
        }
        st.close();
        con.close();
        
    }
    
}
