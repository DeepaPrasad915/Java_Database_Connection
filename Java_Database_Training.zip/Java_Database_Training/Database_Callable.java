import java.sql.*;
import java.util.Scanner;
public class Database_Callable {
    public static void main(String args[])throws ClassNotFoundException, SQLException{
        Connection  conn=null;
        CallableStatement stmt=null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn=DriverManager.getConnection("Jdbc:mysql://localhost:3306/Trinity","root","root");
            String sql="{CALL insert_Emp(?,?,?,?)}";
            stmt= conn.prepareCall(sql);

            Scanner sc=new Scanner(System.in);
            System.out.println("Enter the eid: ");
            int eid=sc.nextInt();
            System.out.println("Enter ename: ");
            String ename= sc.next();
            System.out.println("Enter salary: ");
            int salary=sc.nextInt();
            System.out.println("Enter Dname: ");
            String dname=sc.next();


            stmt.setInt(1,eid);
            stmt.setString(2,ename);
            stmt.setInt(3,salary);
            stmt.setString(4,dname);
            stmt.execute();
            System.out.println("Employee inserted Successfully.....");
        }catch(Exception e){
            e.printStackTrace();
        }
        stmt.close();
        conn.close();
    }

    
}
