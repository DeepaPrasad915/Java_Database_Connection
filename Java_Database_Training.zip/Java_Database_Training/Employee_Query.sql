create database  if not exists Trinity;
use Trinity;
create table  if not exists Employee(eid int primary key,
 ename varchar(100) not null, 
 salary int check(salary>5000),
 dname varchar(50));
 select* from Employee;