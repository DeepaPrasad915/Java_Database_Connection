import java.sql.*;
import java.util.*;

public class Database_Prepared_st {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        // Load driver
        Class.forName("com.mysql.cj.jdbc.Driver");
        System.out.println("Driver loaded Successfully");

        // Establish connection
        Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/Trinity", "root", "root");
        System.out.println("Connected to the database Successfully");

        // Use ? placeholders for prepared statement
        PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO Employee (eid, ename, salary, dname) VALUES (?, ?, ?, ?)");

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the eid: ");
        int id = sc.nextInt();

        System.out.println("Enter the ename: ");
        String name = sc.next();

        System.out.println("Enter the salary: ");
        int salary = sc.nextInt();

        System.out.println("Enter the department: ");
        String dept = sc.next();

        // Bind values
        ps.setInt(1, id);
        ps.setString(2, name);
        ps.setInt(3, salary);
        ps.setString(4, dept);

        // Execute query
        int x = ps.executeUpdate();
        if (x > 0) {
            System.out.println("Inserted Successfully......");
        }

        // Close resources
        ps.close();
        conn.close();
        sc.close();
    }
}
