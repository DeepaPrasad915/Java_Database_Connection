import java.sql.*;
public class Database_Update {
    public static void main(String[] args)throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn = DriverManager.getConnection("Jdbc:mysql://localhost:3306/Trinity", "root","root");
        System.out.println("Connected Successfully");
        Statement st= conn.createStatement();
        String str= "update Employee set ename='Moiz' where ename='Deepa'";
        int row = st.executeUpdate(str);
        if(row>0)
        {
            System.out.println("Updated Succesfully.....");
            st.close();
            conn.close();
        }
    }

    
}
