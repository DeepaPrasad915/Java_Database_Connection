import java.sql.*;
public class Database_connectivity
{
    public static void main(String args[]) throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn= DriverManager.getConnection("Jdbc:mysql://localhost:3306/Trinity","root","root");
        Statement st= conn.createStatement();
        int row= st.executeUpdate("insert into employee values (108, 'Deepa',120000,'IT')");
        if(row>0)
        {
            System.out.println("Inserted Successfully");
            st.close();
            conn.close();
        }
    }
}