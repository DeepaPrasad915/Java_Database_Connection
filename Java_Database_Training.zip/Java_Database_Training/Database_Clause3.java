//Write a JDBC code to fetch the name of the Department where more than 3 employee are working.
import java.sql.*;
public class Database_Clause3 {
    public static void main(String[] args) throws SQLException, ClassNotFoundException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con=DriverManager.getConnection("Jdbc:mysql://localhost:3306/Trinity","root","root");
        System.out.println("Connected Successfully");
        Statement st= con.createStatement();
        String query= "select dname, count(*) from Employee group by dname having count(*) >3";
        ResultSet rs= st.executeQuery(query);
        while(rs.next())
        {
            System.out.println(rs.getString(1)+" "+rs.getInt(2));
            System.out.println("Displaying value....");
        }
        st.close();
        con.close();
        
    }
    }
