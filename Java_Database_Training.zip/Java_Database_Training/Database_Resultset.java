import java.sql.*;

public class Database_Resultset {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        // Load MySQL JDBC Driver
        Class.forName("com.mysql.cj.jdbc.Driver");
        
        // Establish connection
        Connection conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/Trinity", "root", "root");
        
        // Create statement
        Statement st = conn.createStatement();
        
        // Execute query
        ResultSet rs = st.executeQuery("SELECT * FROM Employee");
        
        // Process results
        while (rs.next()) {
            System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getInt(3));
        }
        
        // Close resources
        rs.close();
        st.close();
        conn.close();
    }
}
