use  Trinity;
DELIMITER //
Create procedure insert_Emp (
IN eid INT,
IN ename  VARCHAR(100),
IN salary INT,
IN dname VARCHAR (100)
)
BEGIN
Insert into Employee Values(eid, ename, salary,dname);
END;
//

select * from Employee;
