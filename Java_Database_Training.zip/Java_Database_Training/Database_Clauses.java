//Write a JDBC code to display the no of employee working in each department.
import java.sql.*;
public class Database_Clauses{
    public static void main(String args[])throws SQLException, ClassNotFoundException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection conn=DriverManager.getConnection("Jdbc:mysql://localhost:3306/Trinity","root","root");
        System.out.println("Connected Successfully....");
        Statement st= conn.createStatement();
        ResultSet rs=st.executeQuery("Select dname, count(*) from Employee group by dname");//clauses using group by
        while(rs.next())
        {
            System.out.println(rs.getString(1)+" "+rs.getInt(2));
        }
        st.close();
        conn.close();
    }
}
